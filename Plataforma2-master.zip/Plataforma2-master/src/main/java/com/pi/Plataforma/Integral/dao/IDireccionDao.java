package com.pi.Plataforma.Integral.dao;

import com.pi.Plataforma.Integral.models.Direccion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IDireccionDao extends JpaRepository<Direccion,Long> {
}
