package com.pi.Plataforma.Integral.service;

import com.pi.Plataforma.Integral.models.Actividad;


import java.util.List;

public interface IActividadService {

    List<Actividad> getAll();
}
