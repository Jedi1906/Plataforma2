package com.pi.Plataforma.Integral.dao;

import com.pi.Plataforma.Integral.models.Ussurioooo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IUssuriooooDao extends JpaRepository<Ussurioooo, Long> {

}
