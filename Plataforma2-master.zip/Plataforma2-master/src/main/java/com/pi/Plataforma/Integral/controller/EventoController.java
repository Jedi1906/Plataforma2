package com.pi.Plataforma.Integral.controller;

import com.pi.Plataforma.Integral.models.Evento;
import com.pi.Plataforma.Integral.service.IEventoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/evento")
@CrossOrigin(origins = "*")
public class EventoController {
    private final IEventoService eventoService;

    public EventoController(IEventoService eventoService) {
        this.eventoService = eventoService;
    }

    @GetMapping("/getById/{id_evento}")
    public ResponseEntity<?> getById(@PathVariable(name = "id_evento") Long id_evento) {
        Evento evento = eventoService.getById(id_evento);
        return new ResponseEntity<>(evento, HttpStatus.OK);
    }

    @GetMapping("/getEvento")
    public ResponseEntity<?> getEvento() {
        List<Evento> response = eventoService.getBrokers();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
