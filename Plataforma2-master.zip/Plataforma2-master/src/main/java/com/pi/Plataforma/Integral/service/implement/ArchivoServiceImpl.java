package com.pi.Plataforma.Integral.service.implement;


import com.pi.Plataforma.Integral.dao.IArchivoDao;
import com.pi.Plataforma.Integral.models.Archivo;
import com.pi.Plataforma.Integral.service.IArchivoService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ArchivoServiceImpl implements IArchivoService {

    private final IArchivoDao archivoDao;

    public ArchivoServiceImpl(IArchivoDao archivoDao) {
        this.archivoDao = archivoDao;
    }

    @Override
    public List<Archivo> getAll() {
        return archivoDao.findAll();
    }
}


