package com.pi.Plataforma.Integral;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlataformaIntegralApplicationTests {

	@Test
	void contextLoads() {
	}

}
