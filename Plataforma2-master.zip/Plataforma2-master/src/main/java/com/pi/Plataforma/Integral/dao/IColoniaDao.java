package com.pi.Plataforma.Integral.dao;

import com.pi.Plataforma.Integral.models.Colonia;

import org.springframework.data.jpa.repository.JpaRepository;

public interface IColoniaDao extends JpaRepository <Colonia, Long> {
}
