package com.pi.Plataforma.Integral.service.implement;

import com.pi.Plataforma.Integral.dao.IEventoDao;
import com.pi.Plataforma.Integral.models.Evento;
import com.pi.Plataforma.Integral.service.IEventoService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EventoServiceImpl implements IEventoService {
    private final IEventoDao eventoDao;

    public EventoServiceImpl(IEventoDao eventoDao) {
        this.eventoDao = eventoDao;
    }

    @Override
    public Evento findByAll() {
        return null;
    }

    @Override
    public Evento getById(Long id_evento) {
        return null;
    }

    @Override
    public List<Evento> getBrokers() {
        return null;
    }


}
