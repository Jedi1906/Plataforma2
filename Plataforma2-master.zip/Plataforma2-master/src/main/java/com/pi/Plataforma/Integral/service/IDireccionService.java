package com.pi.Plataforma.Integral.service;

import com.pi.Plataforma.Integral.models.Direccion;


import java.util.List;

public interface IDireccionService {
    Direccion findByAll();

    Direccion getById(Long id_direccion);

    List<Direccion> getBrokers();
}
