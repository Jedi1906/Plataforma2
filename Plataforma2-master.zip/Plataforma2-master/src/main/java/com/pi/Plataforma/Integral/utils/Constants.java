package com.pi.Plataforma.Integral.utils;

public class Constants {
    public static final String frontEndApp ="*";
    public static final String HOST ="http://localhost:4200";
    public static final String DIRECTORIO_UPLOAD = "C:\\uploads\\boutique";
}
