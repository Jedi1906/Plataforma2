package com.pi.Plataforma.Integral.controller;

import com.pi.Plataforma.Integral.models.Direccion;
import com.pi.Plataforma.Integral.service.IDireccionService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/direccion")
@CrossOrigin(origins = "*")
public class DireccionController {
    private final IDireccionService direccionService;

    public DireccionController(IDireccionService direccionService) {
        this.direccionService = direccionService;
    }

    @GetMapping("/getById/{id_direccion}")
    public ResponseEntity<?> getById(@PathVariable(name = "id_direccion") Long id_direccion) {
        Direccion direccion = direccionService.getById(id_direccion);
        return new ResponseEntity<>(direccion, HttpStatus.OK);
    }

    @GetMapping("/getDireccion")
    public ResponseEntity<?> getDireccion() {
        List<Direccion> response = direccionService.getBrokers();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
