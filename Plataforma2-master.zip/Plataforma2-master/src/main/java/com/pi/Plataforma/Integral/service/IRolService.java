package com.pi.Plataforma.Integral.service;

import com.pi.Plataforma.Integral.models.Rol;

import java.util.List;

public interface IRolService {

    List<Rol> getAll();
}
