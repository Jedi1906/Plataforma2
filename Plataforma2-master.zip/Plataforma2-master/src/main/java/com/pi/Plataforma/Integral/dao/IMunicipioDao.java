package com.pi.Plataforma.Integral.dao;

import com.pi.Plataforma.Integral.models.Municipio;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IMunicipioDao extends JpaRepository<Municipio, Long> {
}
