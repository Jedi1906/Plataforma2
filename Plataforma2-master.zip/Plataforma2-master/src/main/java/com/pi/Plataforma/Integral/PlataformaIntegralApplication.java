package com.pi.Plataforma.Integral;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlataformaIntegralApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlataformaIntegralApplication.class, args);
	}

}
