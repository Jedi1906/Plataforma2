package com.pi.Plataforma.Integral.service;

import com.pi.Plataforma.Integral.models.Archivo;

import java.util.List;

public interface IArchivoService {
    List<Archivo> getAll();
}
