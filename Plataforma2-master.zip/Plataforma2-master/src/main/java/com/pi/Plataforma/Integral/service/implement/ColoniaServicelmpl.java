package com.pi.Plataforma.Integral.service.implement;

import com.pi.Plataforma.Integral.models.Colonia;
import com.pi.Plataforma.Integral.service.IColoniaService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ColoniaServicelmpl implements IColoniaService {
    @Override
    public Colonia findByAll() {
        return null;
    }

    @Override
    public Colonia getById(Long id_colonia) {
        return null;
    }

    @Override
    public List<Colonia> getBrokers() {
        return null;
    }
}
